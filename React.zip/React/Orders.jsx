import React,{useState,useEffect} from'react';
import axios from'axios';
import {useParams} from'react-router-dom';

const Orders=()=>{
    let [state,setstate]=useState(null);
    let[count,setcount]=useState(1);
    let {id}=useParams();
    useEffect(()=>{
        axios.get(`https://fakestoreapi.com/products/${id}`).then((res)=>{
            setstate(res.data);
        })
    .catch(()=>{
        console.log("nothing");
    });
    },[])
    let increase =()=>{
        setcount(count+1);
    }
    let decrease =()=>{
        if(count<=1)
        {

        }
        else{
            setcount(count-1);
        }
    }
    let totalprice=()=>{
        return count*state.price;
    }
    return(
        <div>
            {state==null? "loading":(<div key={state.id}>
             <p>{state.title}</p>
             <p>{state.category}</p>
             <p>price-{state.price}</p>
             <button onClick={increase}>+</button>
             {count}
             <button onClick={decrease}>-</button>
             <p>total-price:{totalprice}</p>      
             </div>)}
             </div>
    )

}
export default Orders;