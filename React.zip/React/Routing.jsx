import React from'react';
import { createBrowserRouter,RouterProvider } from 'react-router-dom';
import Layout from"./Layout";
import Products from"./Products";
import Cart from"./Cart";
import Orders from"./Orders";
import Checkout from"./Checkout";
let route=createBrowserRouter([{
    path:"/",
    element:<Layout/>,
    children:[
    {
        index:true,
        element:<Products/>
    },
    {
        path:"/cart/:id",
        element:<Cart/>
    },
    {
        path:"/cart",
        element:<Cart/>
    },

    {
        path:"/orders/:id",
        element:<Orders/>
    },
    {
        path:"/orders",
        element:<Orders/>
    },
    {
        path:"/checkout",
        element:<Checkout/>
    }
    ]
}])
const Routing=()=>{
    return(
        <RouterProvider router={route}></RouterProvider>
    )

}
export default Routing;