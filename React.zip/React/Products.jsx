import React,{useState,useEffect} from'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import style from "./Project.module.css";
const Products=()=>{
    let [state,setstate]=useState([]);
    useEffect(()=>{
        axios.get("https://fakestoreapi.com/products").then((res)=>{
            setstate(res.data);
        }).catch(()=>{
            console.log("Loading...");
        });
    });
    return(
        <div className={style.img}>
        {state.map((data)=>{
            return  <div key={data.id}>
                <p>{data.title}</p>
                <div id={style.item}>
                <img id={style.image} src={data.image}/>
                </div>
                <p>{data.price}</p>
                <p>{data.category}</p>
                <Link to={`/cart/${data.id}`}>Goto Cart</Link>
                </div>
        })}
        </div>
    )

}
export default  Products