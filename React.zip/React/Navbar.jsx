import React from'react';
import { NavLink } from 'react-router-dom';
import style from "./Project.module.css";
const Navbar=()=>{
    return(
        
        <div className={style.nav}>
            <article className={style.left}></article>
            <article className={style.right}>
            <h2 id={style.h2}>Login</h2>
            <NavLink to="/"><h2 className={style.h2}>Products</h2></NavLink>
            <NavLink to="/cart"><h2 className={style.h2}>Cart</h2></NavLink>
            <NavLink to="/order"><h2 className={style.h2}>Order</h2></NavLink>
            <NavLink to="/checkOut"><h2 className={style.h2}>CheckOut</h2></NavLink>
            </article>
        </div>
    )

}
export default Navbar;