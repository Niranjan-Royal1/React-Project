import React ,{useState,useEffect}from'react';
import axios from'axios'
import {Link,useParams} from 'react-router-dom';
import style from "./Project.module.css";
const Cart=()=>{
    let [state,setstate]=useState(null);
    let {id}=useParams();
    useEffect(()=>{
        axios.get(`https://fakestoreapi.com/products/${id}`).then((res)=>{
            setstate(res.data);
        }).catch(()=>{

        });
    },[]);
    return(
        <div>
         {state==null?"nothing":(<div key={state.id}>
        <p> <b>Tittle-</b> {state.title}</p>
        <p> <b>Categeory-</b> {state.category}</p>
        <img id={style.cart}  src={state.image}/>
        <p> <b>Price-</b> {state.price}</p>
        {state.rating ? (
                            <>
                                <p><b>Rating** -</b> {state.rating.rate}</p>
                                <p><b>Count -</b> {state.rating.count}</p>
                            </>
                        ) : (
                            <p>No rating available</p>
                        )}
        <Link to="/">go back </Link>
        <Link to={`/order/${state.id}`}>Ordernow</Link>
         </div>)}
        </div>
    );
}
export default Cart;